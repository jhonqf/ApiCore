﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using consumoApi.Interface;
using consumoApi.Models;
using System.Text.Json;
namespace consumoApi.Controllers
{
   
    public class HttpCallController : Controller { 
        public readonly IHttpCallService _httpCallService;

        public HttpCallController(IHttpCallService httpCallService)
        {

            _httpCallService = httpCallService;
        }


        [HttpGet]
        //[Route("GetData")]
        public async Task<IActionResult> Get()
        {
            try
            {
                var response = await _httpCallService.GetData<DataModel>();
                return (response is null) ? NotFound(response) : Ok(response);
            }
            catch (Exception)
            {
                throw;
            }
        }

        //[HttpGet]
        //public IActionResult Get()
        //{
        //    var myObject = new { Name = "John", Age = 30 };
        //    return Ok(myObject);
        //}
    }
}
