﻿using Microsoft.Net.Http.Headers;
using System.Net.Http;

namespace consumoApi.Interface
{
    public interface IHttpCallService
    {
        public Task<T> GetData<T>();
       

    }
}
